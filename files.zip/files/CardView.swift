//
//  CardView.swift
//  Project01
//
//  Created by abdullah FH on 06/05/1446 AH.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI
   

struct CardView: View {
    var product: ProductModel
    @State var show = false
    @State var color = Color("Color")
    var body: some View {
        VStack {
            
            VStack(spacing: 35){
                
                WebImage(url: URL(string: product.ProductImage!)!)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 200, height: 200)
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .onTapGesture {
                        show = true
                    }
                
                HStack{
                    
                    
                    Button(action: {}) {
                        
                        Image(systemName: "plus")
                            .foregroundColor(.black)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(15)
                    }
                    
                    Spacer(minLength: 0)
                    
                    VStack(alignment: .leading, spacing: 6) {
                        
                        Text(product.ProductName!)
                            .foregroundColor(color)
                            .multilineTextAlignment(.trailing)
                        Text("\(product.ProductPrice!, specifier: "%.2f")")
                            .fontWeight(.bold)
                            .foregroundColor(color)
                    }
                    
                  
                }
                .padding(.horizontal)
            }
            .padding(.bottom)
            .background(
                
                LinearGradient(gradient: .init(colors: [Color.white.opacity(0.1),Color.black.opacity(0.35)]), startPoint: .top, endPoint: .bottom)
                    .cornerRadius(25)
                    .padding(.top,55)
            )
        }.sheet(isPresented: $show) {
            DetailsView(product: product)
        }
    }
}

