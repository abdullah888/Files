//
//  Home.swift
//  Project01
//
//  Created by abdullah FH on 06/05/1446 AH.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI

struct Home: View {
    @StateObject var ProductData = ProductViewModel()
    var animation: Namespace.ID
    @State var ShowSearch = false
    @State var Showbasket = false
    @State var color = Color("Color")
    func Header(title: String) -> HStack<TupleView<(Text, Spacer)>> {
        return // since both are same so were going to make it as reuable...
            HStack{
                
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(color)
                
                Spacer()
            }
    }
    
    var body: some View {
       
        VStack{
            
            ZStack{
                
                HStack{
                    
                    Text(Date(), style: .time)
                        .font(.title2)
                        .foregroundColor(color)
                    
                    Spacer()
                    
                    Button(action: {
          
                        Showbasket = true
                    }) {
                        
                        Image(systemName: "basket")
                            .font(.title2)
                            .foregroundColor(color)
                    }
                    Button(action: {
          
                        ShowSearch = true
                    }) {
                        
                        Image(systemName: "magnifyingglass")
                            .font(.title2)
                            .foregroundColor(color)
                    }
                 
                }
                
                Text("المتجر الخاص")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(color)
            }
            .padding([.horizontal,.bottom])
            .padding(.top,10)
            
            ScrollView(.vertical, showsIndicators: false) {
                
                VStack{
                    
                    Header(title: "الاطباق المميزة")
                    .padding()
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        
                        HStack(spacing: 25){
                            
                            ForEach(ProductData.products){product in
                                
                                // Card View....
                                
                                CardView1(product: product)
                            }
                        }
                        .padding()
                        .padding(.horizontal,4)
                    }
                    
                    Header(title: "الاطباق المتوفره")
                    .padding()
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        
                        HStack(spacing: 25){
                            
                            ForEach(ProductData.products){product in
                                
                                // Card View....
                                
                                CardView(product: product)
                            }
                        }
                        .padding()
                        .padding(.horizontal,4)
                    }
                    
                    Header(title: "الاطباق المنفردة")
                    .padding()
                    
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        
                        HStack(spacing: 25){
                            
                            ForEach(ProductData.products){product in
                                
                                // Card View....
                                
                                CardView2(product: product)
                            }
                        }
                        .padding()
                        .padding(.horizontal,4)
                    }
                    
                }
                .padding(.bottom,100)
            }
        }.sheet(isPresented: $ShowSearch) {
            Search()
        }.sheet(isPresented: $Showbasket) {
            Basket()
        }
    }
}
